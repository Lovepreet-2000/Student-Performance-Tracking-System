<?php
include 'db_connect.php'; // Include the database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST['date']; // Match column name
    $student_id = $_POST['student_id'];
    $status = $_POST['status'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $student_id, $date, $status);

    if ($stmt->execute()) {
        echo "Attendance recorded successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
