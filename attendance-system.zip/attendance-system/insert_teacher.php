<?php
include 'db_connect.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['teacher_name'];
    $teacher_id = $_POST['teacher_id'];
    $email = $_POST['teacher_email'];
    $gender = $_POST['teacher_gender'];
    $dob = $_POST['teacher_dob'];
    $subject = $_POST['teacher_subject'];

    // File Upload Handling
    $photo = $_FILES['teacher_photo']['name'];
    $target_dir = "uploads/";  // Folder where photos will be stored
    $target_file = $target_dir . basename($photo);

    // Ensure 'uploads' directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($_FILES["teacher_photo"]["tmp_name"], $target_file)) {
        
        // Insert Query using Prepared Statements
        $stmt = $conn->prepare("INSERT INTO teachers (name, teacher_id, email, gender, dob, subject, photo) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $name, $teacher_id, $email, $gender, $dob, $subject, $target_file);

        if ($stmt->execute()) {
            echo "Teacher registered successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error uploading the photo.";
    }

    $conn->close(); // Close database connection
}
?>
