<?php
include 'db_connect.php'; // Ensure the database connection is included

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['student_name'];
    $email = $_POST['student_email'];
    $class = $_POST['student_class'];
    $student_id = $_POST['student_id'];
    $gender = $_POST['student_gender'];
    $dob = $_POST['student_dob'];

    // Handling file upload
    $photo = $_FILES['student_photo']['name'];
    $target_dir = "uploads/";  // Folder where photos will be stored
    $target_file = $target_dir . basename($photo);

    // Ensure 'uploads/' directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    if (move_uploaded_file($_FILES["student_photo"]["tmp_name"], $target_file)) {
        // SQL Query to insert data
        $sql = "INSERT INTO students (name, student_id, email, gender, dob, class, photo) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssss", $name, $student_id, $email, $gender, $dob, $class, $target_file);

        if ($stmt->execute()) {
            echo "Student registered successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error uploading file.";
    }

    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
