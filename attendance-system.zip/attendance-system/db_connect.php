<?php
$servername = "localhost";  // Change if using a different server
$username = "root";         // Change if using a different username
$password = "";             // Change if using a password
$database = "student_performance"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 for better character encoding support
$conn->set_charset("utf8mb4");

?>
