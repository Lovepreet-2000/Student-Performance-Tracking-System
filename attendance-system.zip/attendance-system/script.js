// Basic functionality for form submission, validation, etc.
document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    
    form.addEventListener('submit', function (event) {
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            if (input.value === '') {
                event.preventDefault();
                alert('Please fill out all fields.');
            }
        });
    });
});
