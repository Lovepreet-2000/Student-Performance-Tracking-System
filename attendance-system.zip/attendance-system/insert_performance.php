<?php
include 'db_connect.php'; // Ensure you have a database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = trim($_POST['student_id']);
    $subject = trim($_POST['subject']);

    // Validate input
    if (empty($student_id) || empty($subject)) {
        die("Error: Please fill in all fields.");
    }

    // Fetch student performance based on student_id and subject
    $stmt = $conn->prepare("SELECT score FROM performance WHERE student_id = ? AND subject = ?");
    $stmt->bind_param("ss", $student_id, $subject);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if record is found
    if ($row = $result->fetch_assoc()) {
        // If record is found, display the score
        echo "Performance Score for " . ucfirst($subject) . " is: " . $row['score'];
    } else {
        // If no record found, display a message
        echo "No performance record found for student ID " . $student_id . " in the selected subject: " . ucfirst($subject);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
